-- MariaDB dump 10.19  Distrib 10.4.18-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: Bank
-- ------------------------------------------------------
-- Server version	10.4.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `Account_no` varchar(55) NOT NULL,
  `Cash` int(11) NOT NULL,
  `Account_type` varchar(55) NOT NULL,
  `customer` int(11) DEFAULT NULL,
  PRIMARY KEY (`Account_no`),
  KEY `customer` (`customer`),
  CONSTRAINT `account_ibfk_1` FOREIGN KEY (`customer`) REFERENCES `customers` (`Customer_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES ('00000007M',1000000000,'Fixed Deposit',15),('00525225N',2000000000,'Saving',13),('02581520B',2147483647,'Current',14),('25225252R',700000,'Saving',3),('40525255J',500000000,'Saving',1),('4444444E',1000,'Current',12),('52052520V',9000000,'DEMAT',2),('52505202O',2147483647,'Fixed Deposit',5),('52525252T',2147483647,'DEMAT',4),('77858282I',700000000,'Current',9),('78828282U',890000000,'DEMAT',7),('85222222222I',1000000,'Saving',10),('85892522Y',858220,'Current',6),('9958585858Q',9582820,'Saving',11),('99999949P',900082,'Fixed Deposit',8);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_service`
--

DROP TABLE IF EXISTS `customer_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_service` (
  `CS_ID` int(11) NOT NULL,
  `Service` int(11) DEFAULT NULL,
  `Customer` int(11) DEFAULT NULL,
  PRIMARY KEY (`CS_ID`),
  KEY `Service` (`Service`),
  KEY `Customer` (`Customer`),
  CONSTRAINT `customer_service_ibfk_1` FOREIGN KEY (`Service`) REFERENCES `services` (`Service_ID`),
  CONSTRAINT `customer_service_ibfk_2` FOREIGN KEY (`Customer`) REFERENCES `customers` (`Customer_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_service`
--

LOCK TABLES `customer_service` WRITE;
/*!40000 ALTER TABLE `customer_service` DISABLE KEYS */;
INSERT INTO `customer_service` VALUES (100,1,15),(101,2,14),(102,3,13),(103,4,12),(104,5,11),(105,5,10),(106,4,9),(107,3,8),(108,2,7),(109,1,6),(110,3,5),(111,2,4),(112,4,3),(113,1,2),(114,5,1),(115,2,4),(116,3,7),(117,5,1),(118,3,9),(119,4,14);
/*!40000 ALTER TABLE `customer_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `Customer_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(55) NOT NULL,
  `Email` varchar(55) NOT NULL,
  `Address` varchar(55) NOT NULL,
  `Phone` varchar(55) NOT NULL,
  `Staff` int(11) DEFAULT NULL,
  PRIMARY KEY (`Customer_ID`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `Phone` (`Phone`),
  KEY `Staff` (`Staff`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`Staff`) REFERENCES `staffs` (`Staff_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Gopal','gopal@gmail.com','Mahendrapool','9813256211',10),(2,'Hari','hari@gmail.com','Campus Chowk','9800000088',8),(3,'Sunil','sunil@gmail.com','Indra Chowk','9811112233',9),(4,'Tikaram','tikaram@gmail.com','Nadipur','9877775522',6),(5,'Surya','surya@gmail.com','Damside','981212456',4),(6,'Aasish','aasish@gmail.com','Cauthe','9821347520',7),(7,'Bhuwan','bhuwan@gmail.com','Chorepatan','9844923564',3),(8,'Diwakar','diwakar@gmail.com','Parsyang','9847682423',1),(9,'Subash','subash@gmail.com','Nagdhunga','9805250879',2),(10,'Sulav','sulav@gmail.com','Galeshowr','9846609420',5),(11,'Dipesh','dipesh@gmail.com','Nagdhunga','9875620012',8),(12,'Bimal','bimal@gmail.com','Damside','9875220113',6),(13,'Bikash','bikash@gmail.com','Newroad','9877777220',1),(14,'Nitesh','nitesh@gmail.com','Ratnachowk','9802020202',9),(15,'Rabina','rabina@gmail.com','Parsyang','9855220011',3);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `Depart_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Depart_Name` varchar(55) NOT NULL,
  `Location` varchar(55) NOT NULL,
  PRIMARY KEY (`Depart_ID`),
  UNIQUE KEY `Depart_Name` (`Depart_Name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'Financial Inlusion','Ground floor'),(2,'Digital Banking','First floor'),(3,'Information Technology','First floor'),(4,'Law','Second floor'),(5,'Loan','Ground floor');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `Service_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Service_Name` varchar(55) NOT NULL,
  PRIMARY KEY (`Service_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (1,'ATM Card'),(2,'Locker Facility'),(3,'Debit Card'),(4,'SMS Banking'),(5,'Internet Banking');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staffs`
--

DROP TABLE IF EXISTS `staffs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staffs` (
  `Staff_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(55) NOT NULL,
  `Email` varchar(55) NOT NULL,
  `Phone` varchar(55) NOT NULL,
  `Address` varchar(55) NOT NULL DEFAULT 'Myagdi',
  `Department` int(11) DEFAULT NULL,
  `Salary` int(11) DEFAULT NULL,
  PRIMARY KEY (`Staff_ID`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `Phone` (`Phone`),
  KEY `Department` (`Department`),
  CONSTRAINT `staffs_ibfk_1` FOREIGN KEY (`Department`) REFERENCES `departments` (`Depart_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staffs`
--

LOCK TABLES `staffs` WRITE;
/*!40000 ALTER TABLE `staffs` DISABLE KEYS */;
INSERT INTO `staffs` VALUES (1,'Sandesh','ava@gmail.com','9812121212','Kajipokhari',1,NULL),(2,'Riva','bab@gmail.com','9821212121','Malepatan',1,NULL),(3,'Usha','tat@gmail.com','9889898989','Newroad',2,NULL),(4,'Rojan','uyuy@gmail. com','9874747474','Newroad',3,NULL),(5,'Vaskar','iki@gmail.com','9845454545','',2,NULL),(6,'Maya','lala@gmail.com','9810101010','Hari Chowk',4,NULL),(7,'Raj','cat@gamil.com','9865656565','Birauta',3,NULL),(8,'Manish','was@gmail.com','9820202020','Buspark',5,NULL),(9,'Amrit','aka@gmail.com','9855445544','Birauta',5,NULL),(10,'Ram','iji@gmail.com','9899889988','Pame',4,NULL);
/*!40000 ALTER TABLE `staffs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-30 22:36:44
